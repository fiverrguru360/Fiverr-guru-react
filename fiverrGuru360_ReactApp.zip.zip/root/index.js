import React from 'react';
import ReactDOM from 'react-dom/client';
import FiverrGuru360 from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<FiverrGuru360 />);
